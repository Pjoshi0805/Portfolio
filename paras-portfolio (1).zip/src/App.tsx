/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { motion, useMotionValue, useSpring, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { Instagram, Linkedin, ArrowRight, Star } from 'lucide-react';

// --- Components ---

const Navigation = () => {
  const navItems = [
    { label: 'ABOUT', href: '#about' },
    { label: 'SKILLS', href: '#skills' },
    { label: 'PROJECTS', href: '#projects' },
    { label: 'CONTACT', href: '#contact' },
  ];
  
  const socialItems = [
    { label: 'INSTA', href: '#' },
  ];

  return (
    <nav className="fixed top-0 left-0 w-full p-8 flex justify-end items-start z-50 mix-blend-difference pointer-events-none">
      <div className="flex flex-wrap justify-end gap-x-8 lg:gap-x-12 gap-y-4 pointer-events-auto max-w-xl">
        {navItems.map((item) => (
          <a
            key={item.label}
            href={item.href}
            className="text-[10px] tracking-[0.2em] font-medium transition-all duration-500 relative group cursor-pointer text-white"
          >
            {item.label}
            <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-white transition-all duration-500 group-hover:w-full" />
          </a>
        ))}
        {socialItems.map((item) => (
          <a
            key={item.label}
            href={item.href}
            className="text-[10px] tracking-[0.2em] font-medium text-white/60 hover:text-white transition-colors"
          >
            {item.label}
          </a>
        ))}
      </div>
    </nav>
  );
};

const SectionHero = () => {
  const letters = ['P', 'a', 'r', 'a', 's'];
  
  return (
    <motion.section
      id="about"
      initial={{ backgroundColor: '#D1A740' }}
      animate={{ backgroundColor: '#D1A740' }}
      className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden py-32"
    >
      <div className="relative flex flex-col items-center text-center px-8 z-10">
        <motion.div 
           initial={{ opacity: 0, y: 50 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
           className="relative"
        >
          <span className="absolute -top-12 right-0 text-[10px] tracking-[0.2em] font-medium opacity-50">(2026)</span>
          <h1 className="text-[18vw] leading-[0.8] font-serif font-black tracking-tighter text-brand-dark flex items-baseline justify-center cursor-default">
            {letters.map((letter, i) => (
              <span 
                key={i} 
                className={`relative inline-block hover:text-white transition-colors duration-500 ${letter === 'a' && i === 1 ? 'italic' : ''}`}
              >
                {letter}
              </span>
            ))}
          </h1>
        </motion.div>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          transition={{ delay: 0.8, duration: 1 }}
          className="mt-8 text-[12px] tracking-widest font-medium uppercase"
        >
          Art Director & Designer
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 0.7, y: 0 }}
          transition={{ delay: 1.2, duration: 1.5 }}
          className="mt-12 max-w-[400px]"
        >
          <p className="text-[13px] leading-relaxed tracking-wider font-medium serif italic">
            "I live between lines of code and lines of poetry — building things that breathe, that load in milliseconds but linger in memory. I love to code the way others love to paint: with intention, with mess, and with something true at the center."
          </p>
        </motion.div>
      </div>

      <div className="absolute top-12 left-12">
        <Star className="w-6 h-6 opacity-40 shrink-0" strokeWidth={1} />
      </div>
    </motion.section>
  );
};

const SectionSkills = () => {
  const [hoveredSkill, setHoveredSkill] = useState<number | null>(null);
  
  const skills = [
    { name: 'React', img: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2070&auto=format&fit=crop' },
    { name: 'TypeScript', img: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?q=80&w=2128&auto=format&fit=crop' },
    { name: 'Node.js', img: 'https://images.unsplash.com/photo-1502945015378-0e28402264b1?q=80&w=2070&auto=format&fit=crop' },
    { name: 'Python', img: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=2070&auto=format&fit=crop' },
    { name: 'UI/UX Design', img: 'https://images.unsplash.com/photo-1586717791821-3f44a563eb4c?q=80&w=2070&auto=format&fit=crop' },
    { name: 'Framer Motion', img: 'https://images.unsplash.com/photo-1550684848-86a5d8727436?q=80&w=2070&auto=format&fit=crop' },
    { name: 'PostgreSQL', img: 'https://images.unsplash.com/photo-1542744094-3a31f272c490?q=80&w=2070&auto=format&fit=crop' },
    { name: 'Tailwind CSS', img: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?q=80&w=2062&auto=format&fit=crop' },
    { name: 'Docker', img: 'https://images.unsplash.com/photo-1605745341112-85968b193ef5?q=80&w=2071&auto=format&fit=crop' }
  ];

  return (
    <section id="skills" className="bg-brand-cream px-12 lg:px-32 py-48 relative border-t border-brand-dark/10">
      <div className="max-w-7xl mx-auto">
        <motion.h2 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-[8vw] leading-none mb-24 font-serif"
        >
          Skills
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 lg:gap-24">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.8 }}
              className="group relative"
              onMouseEnter={() => setHoveredSkill(index)}
              onMouseLeave={() => setHoveredSkill(null)}
            >
              <div className="flex items-center gap-6 pb-6 border-b border-brand-dark/10 group-hover:border-brand-yellow transition-colors duration-500">
                <span className="text-[10px] opacity-30 font-display">0{index + 1}</span>
                <h3 className="text-2xl lg:text-4xl font-serif group-hover:italic transition-all duration-300">{skill.name}</h3>
              </div>

              <AnimatePresence>
                {hoveredSkill === index && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8, rotate: -5, y: -20 }}
                    animate={{ opacity: 1, scale: 1, rotate: 0, y: -40 }}
                    exit={{ opacity: 0, scale: 1.1, y: -60 }}
                    transition={{ type: "spring", damping: 20, stiffness: 100 }}
                    className="absolute bottom-full left-1/2 -translate-x-1/2 w-48 h-32 z-50 pointer-events-none overflow-hidden rounded-lg shadow-2xl"
                  >
                    <img 
                      src={skill.img} 
                      alt={skill.name} 
                      className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-1000" 
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ProjectCard = ({ title, description, category, index = 0 }: { title: string, description: string, category: string, index?: number }) => {
  const [hovered, setHovered] = useState(false);
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, delay: index * 0.1 }}
      className="relative group border-b border-brand-dark/10 py-12 lg:py-20 flex flex-col lg:flex-row lg:items-center justify-between gap-8 cursor-pointer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="max-w-2xl">
        <span className="text-[10px] tracking-[0.3em] opacity-40 uppercase mb-4 block">{category}</span>
        <h4 className="text-4xl lg:text-7xl font-serif group-hover:italic transition-all duration-700">{title}</h4>
        <p className="mt-6 text-sm lg:text-base opacity-60 leading-relaxed max-w-lg transition-all duration-500 group-hover:opacity-100">
          {description}
        </p>
      </div>
      
      <div className="flex items-center gap-6">
        <motion.div
          animate={{ x: hovered ? 20 : 0, rotate: hovered ? 45 : 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="bg-brand-yellow p-6 lg:p-10 rounded-full"
        >
          <ArrowRight className="w-8 h-8 lg:w-12 lg:h-12 text-brand-dark" strokeWidth={1} />
        </motion.div>
      </div>
    </motion.div>
  );
}

const SectionProjects = () => {
  return (
    <section id="projects" className="bg-brand-cream px-12 lg:px-32 py-32 border-t border-brand-dark/10">
      <motion.h2 
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="text-[8vw] leading-none mb-24 font-serif"
      >
        Projects
      </motion.h2>
      <div className="max-w-7xl mx-auto flex flex-col">
        <ProjectCard 
          index={0}
          category="01 / AI Product"
          title="Neural Task Orchestrator" 
          description="An intelligent workflow automation engine that uses deep learning to predict and route project tasks efficiently across distributed teams."
        />
        <ProjectCard 
          index={1}
          category="02 / Design System"
          title="Aether UI Framework" 
          description="A comprehensive, multi-platform design system built with performance and accessibility at its core, enabling rapid prototyping for enterprise applications."
        />
        <ProjectCard 
          index={2}
          category="03 / E-Commerce"
          title="Vanguard Commerce" 
          description="A next-generation digital storefront architecture focusing on immersive 3D product previews and a zero-latency checkout experience."
        />
      </div>
    </section>
  );
}

const SectionContact = () => {
  return (
    <section id="contact" className="min-h-screen w-full flex flex-col items-center justify-center bg-brand-cream py-32 px-12 lg:px-32 relative border-t border-brand-dark/10">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="max-w-4xl w-full text-center"
      >
        <h2 className="text-[10vw] font-serif mb-12 leading-none">Let's Build Something.</h2>
        <motion.a 
          whileHover={{ x: 10 }}
          href="mailto:paras521851@gmail.com" 
          className="text-2xl lg:text-5xl font-serif text-brand-yellow hover:text-brand-dark transition-colors inline-flex items-center gap-4 border-b-2 border-brand-yellow pb-4"
        >
          paras521851@gmail.com <ArrowRight className="w-8 h-8 lg:w-12 lg:h-12" />
        </motion.a>
        
        <div className="mt-24 flex justify-center gap-16">
           <a href="#" className="group flex flex-col items-center gap-4">
              <Instagram className="w-10 h-10 group-hover:text-brand-yellow transition-colors" strokeWidth={1} />
              <span className="text-[10px] tracking-widest opacity-40 uppercase">Instagram</span>
           </a>
           <a href="#" className="group flex flex-col items-center gap-4">
              <Linkedin className="w-10 h-10 group-hover:text-brand-yellow transition-colors" strokeWidth={1} />
              <span className="text-[10px] tracking-widest opacity-40 uppercase">LinkedIn</span>
           </a>
        </div>
      </motion.div>
    </section>
  );
}

const CustomCursor = () => {
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);
  const springConfig = { damping: 25, stiffness: 150 };
  const cursorXSpring = useSpring(cursorX, springConfig);
  const cursorYSpring = useSpring(cursorY, springConfig);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
    };
    window.addEventListener('mousemove', moveCursor);
    return () => window.removeEventListener('mousemove', moveCursor);
  }, [cursorX, cursorY]);

  return (
    <motion.div
      className="fixed top-0 left-0 w-8 h-8 bg-brand-yellow rounded-full pointer-events-none z-[9999] mix-blend-difference hidden lg:block"
      style={{
        x: cursorXSpring,
        y: cursorYSpring,
        translateX: '-50%',
        translateY: '-50%',
      }}
    />
  );
};

const FloatingPetal = ({ delay = 0, style = {} }: { delay?: number, style?: any }) => (
  <motion.div
    initial={{ y: -20, x: -20, rotate: 0, opacity: 0 }}
    animate={{ 
      y: [0, 200, 400, 600, 800],
      x: [0, 40, -40, 60, -60],
      rotate: [0, 90, -90, 180, 0],
      opacity: [0, 0.4, 0.4, 0.4, 0]
    }}
    transition={{ 
      duration: 15,
      repeat: Infinity,
      delay: delay,
      ease: "easeInOut"
    }}
    className="fixed pointer-events-none z-0"
    style={style}
  >
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-white">
      <path d="M12 2C12 2 15 8 18 10C21 12 22 15 20 18C18 21 14 22 12 20C10 22 6 21 4 18C2 15 3 12 6 10C9 8 12 2 12 2Z" fill="currentColor" />
    </svg>
  </motion.div>
);

// --- Main App ---

export default function App() {
  const scrollRef = useRef(null);

  return (
    <main className="relative bg-brand-cream overflow-x-hidden scroll-smooth selection:bg-brand-yellow selection:text-brand-dark" ref={scrollRef}>
      <CustomCursor />
      <Navigation />
      
      {/* Background Floating Elements */}
      <FloatingPetal delay={0} style={{ top: '10%', left: '10%' }} />
      <FloatingPetal delay={4} style={{ top: '30%', left: '80%' }} />
      <FloatingPetal delay={8} style={{ top: '60%', left: '15%' }} />
      <FloatingPetal delay={2} style={{ top: '80%', left: '70%' }} />

      <SectionHero />
      <SectionSkills />
      <SectionProjects />
      <SectionContact />

      <footer className="p-12 text-center border-t border-brand-dark/10 bg-brand-cream relative z-10">
        <p className="text-[10px] tracking-[0.4em] uppercase opacity-40">
          © 2026 Paras — paras521851@gmail.com
        </p>
      </footer>
    </main>
  );
}


